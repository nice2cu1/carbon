create definer = root@localhost view v_scm_purchase_return_detail as
select `rd`.`material_id`     AS `material_id`,
       `rd`.`batch_no`        AS `batch_no`,
       `rd`.`price`           AS `price`,
       `rd`.`book_quantity`   AS `book_quantity`,
       `rd`.`arrive_quantity` AS `arrive_quantity`,
       `rd`.`return_quantity` AS `return_quantity`,
       `m`.`name`             AS `material_name`,
       `m`.`code`             AS `material_code`,
       `m`.`model`            AS `material_model`,
       `m`.`specification`    AS `material_specification`,
       `m`.`unit`             AS `material_unit`,
       `r`.`return_date`      AS `return_date`,
       `r`.`return_no`        AS `return_no`,
       `r`.`supplier_id`      AS `supplier_id`,
       `s`.`name`             AS `supplier_name`
from (((`carbon`.`scm_purchase_return_detail` `rd` left join `carbon`.`scm_purchase_return` `r`
        on ((`r`.`id` = `rd`.`return_id`))) left join `carbon`.`scm_purchase_supplier` `s`
       on ((`s`.`id` = `r`.`supplier_id`))) left join `carbon`.`wms_material_info` `m`
      on ((`m`.`id` = `rd`.`material_id`)));

-- comment on column v_scm_purchase_return_detail.material_id not supported: 物料id

-- comment on column v_scm_purchase_return_detail.batch_no not supported: 生产批号

-- comment on column v_scm_purchase_return_detail.price not supported: 单价

-- comment on column v_scm_purchase_return_detail.book_quantity not supported: 订货数量

-- comment on column v_scm_purchase_return_detail.arrive_quantity not supported: 到货数量

-- comment on column v_scm_purchase_return_detail.return_quantity not supported: 退货数量

-- comment on column v_scm_purchase_return_detail.material_name not supported: 物料名称

-- comment on column v_scm_purchase_return_detail.material_code not supported: 物料编码

-- comment on column v_scm_purchase_return_detail.material_model not supported: 型号

-- comment on column v_scm_purchase_return_detail.material_specification not supported: 规格

-- comment on column v_scm_purchase_return_detail.material_unit not supported: 单位

-- comment on column v_scm_purchase_return_detail.return_date not supported: 退货日期

-- comment on column v_scm_purchase_return_detail.return_no not supported: 退货单号

-- comment on column v_scm_purchase_return_detail.supplier_id not supported: 供应商id

-- comment on column v_scm_purchase_return_detail.supplier_name not supported: 供应商名称

