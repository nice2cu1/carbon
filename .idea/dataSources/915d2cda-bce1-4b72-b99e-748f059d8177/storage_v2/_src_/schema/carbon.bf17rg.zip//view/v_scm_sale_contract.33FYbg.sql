create definer = root@localhost view v_scm_sale_contract as
select `sc`.`id`                                 AS `contract_id`,
       `sc`.`contract_no`                        AS `contract_no`,
       `sc`.`order_id`                           AS `order_id`,
       `sc`.`order_no`                           AS `order_no`,
       `sc`.`customer_id`                        AS `customer_id`,
       `c`.`name`                                AS `customer_name`,
       ifnull(`sc`.`contract_amount`, 0)         AS `contract_amount`,
       date_format(`sc`.`sign_date`, '%Y')       AS `contract_year`,
       quarter(`sc`.`sign_date`)                 AS `contract_quarter`,
       month(`sc`.`sign_date`)                   AS `contract_month`,
       date_format(`sc`.`sign_date`, '%Y-%m')    AS `contract_year_month`,
       date_format(`sc`.`sign_date`, '%Y-%m-%d') AS `contract_date`
from ((`carbon`.`scm_sale_contract` `sc` left join `carbon`.`scm_sale_order` `o`
       on ((`sc`.`order_id` = `o`.`id`))) left join `carbon`.`scm_sale_customer` `c`
      on ((`sc`.`customer_id` = `c`.`id`)))
where (`sc`.`audit_status` = '1');

-- comment on column v_scm_sale_contract.contract_id not supported: 编号

-- comment on column v_scm_sale_contract.contract_no not supported: 合同编号

-- comment on column v_scm_sale_contract.order_id not supported: 订单id

-- comment on column v_scm_sale_contract.order_no not supported: 订单编号

-- comment on column v_scm_sale_contract.customer_id not supported: 客户id

-- comment on column v_scm_sale_contract.customer_name not supported: 客户名称

