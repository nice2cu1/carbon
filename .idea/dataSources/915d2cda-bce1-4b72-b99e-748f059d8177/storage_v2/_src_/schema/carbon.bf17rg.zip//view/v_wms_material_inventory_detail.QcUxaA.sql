create definer = root@localhost view v_wms_material_inventory_detail as
select `t`.`wh_id`          AS `wh_id`,
       `t`.`wh_region_id`   AS `wh_region_id`,
       `t`.`wh_location_id` AS `wh_location_id`,
       `t`.`inventory`      AS `inventory`,
       `t`.`lock_inventory` AS `lock_inventory`,
       `t`.`batch_no`       AS `batch_no`,
       `t`.`manufacturer`   AS `manufacturer`,
       `wm`.`material_id`   AS `material_id`,
       `wm`.`max_inventory` AS `max_inventory`,
       `wm`.`min_inventory` AS `min_inventory`,
       `m`.`name`           AS `material_name`,
       `m`.`model`          AS `material_model`,
       `m`.`specification`  AS `material_specification`,
       `m`.`unit`           AS `material_unit`,
       `w`.`name`           AS `wh_name`,
       `r`.`name`           AS `wh_region_name`,
       `wl`.`name`          AS `wh_location_name`
from (((((`carbon`.`wms_warehouse_material_detail` `t` left join `carbon`.`wms_warehouse_material` `wm`
          on ((`wm`.`id` = `t`.`wh_material_id`))) left join `carbon`.`wms_warehouse` `w`
         on ((`w`.`id` = `t`.`wh_id`))) left join `carbon`.`wms_warehouse_region` `r`
        on ((`r`.`id` = `t`.`wh_region_id`))) left join `carbon`.`wms_warehouse_location` `wl`
       on ((`wl`.`id` = `t`.`wh_location_id`))) left join `carbon`.`wms_material_info` `m`
      on ((`m`.`id` = `wm`.`material_id`)))
where (`t`.`wh_id` is not null);

-- comment on column v_wms_material_inventory_detail.wh_id not supported: 仓库编号

-- comment on column v_wms_material_inventory_detail.wh_region_id not supported: 库区编号

-- comment on column v_wms_material_inventory_detail.wh_location_id not supported: 库位编号

-- comment on column v_wms_material_inventory_detail.inventory not supported: 库存量

-- comment on column v_wms_material_inventory_detail.lock_inventory not supported: 锁定库存

-- comment on column v_wms_material_inventory_detail.batch_no not supported: 生产批号

-- comment on column v_wms_material_inventory_detail.manufacturer not supported: 生产厂家

-- comment on column v_wms_material_inventory_detail.material_id not supported: 物料档案编号

-- comment on column v_wms_material_inventory_detail.max_inventory not supported: 库存上限

-- comment on column v_wms_material_inventory_detail.min_inventory not supported: 库存下限

-- comment on column v_wms_material_inventory_detail.material_name not supported: 物料名称

-- comment on column v_wms_material_inventory_detail.material_model not supported: 型号

-- comment on column v_wms_material_inventory_detail.material_specification not supported: 规格

-- comment on column v_wms_material_inventory_detail.material_unit not supported: 单位

-- comment on column v_wms_material_inventory_detail.wh_name not supported: 仓库名

-- comment on column v_wms_material_inventory_detail.wh_region_name not supported: 库区名称

-- comment on column v_wms_material_inventory_detail.wh_location_name not supported: 库区名称

