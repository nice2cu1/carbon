create definer = root@localhost view v_scm_sale_contract_detail as
select `cd`.`contract_id`    AS `contract_id`,
       `c`.`contract_no`     AS `contract_no`,
       `o`.`id`              AS `order_id`,
       `o`.`order_no`        AS `order_no`,
       `c`.`customer_id`     AS `customer_id`,
       `c`.`contract_amount` AS `contract_amount`,
       `c`.`sign_date`       AS `sign_date`,
       `sc`.`name`           AS `customer_name`,
       `cd`.`material_id`    AS `material_id`,
       `cd`.`price`          AS `price`,
       `cd`.`quantity`       AS `quantity`,
       `cd`.`amount`         AS `amount`,
       `m`.`name`            AS `material_name`,
       `m`.`model`           AS `material_model`,
       `m`.`specification`   AS `material_specification`,
       `m`.`unit`            AS `material_unit`
from ((((`carbon`.`scm_sale_contract_detail` `cd` left join `carbon`.`scm_sale_contract` `c`
         on ((`c`.`id` = `cd`.`contract_id`))) left join `carbon`.`scm_sale_order` `o`
        on ((`o`.`id` = `c`.`order_id`))) left join `carbon`.`wms_material_info` `m`
       on ((`m`.`id` = `cd`.`material_id`))) left join `carbon`.`scm_sale_customer` `sc`
      on ((`sc`.`id` = `c`.`customer_id`)))
where (`c`.`audit_status` = '1');

-- comment on column v_scm_sale_contract_detail.contract_id not supported: 合同id

-- comment on column v_scm_sale_contract_detail.contract_no not supported: 合同编号

-- comment on column v_scm_sale_contract_detail.order_id not supported: 编号

-- comment on column v_scm_sale_contract_detail.order_no not supported: 订单编号

-- comment on column v_scm_sale_contract_detail.customer_id not supported: 客户id

-- comment on column v_scm_sale_contract_detail.contract_amount not supported: 合同金额

-- comment on column v_scm_sale_contract_detail.sign_date not supported: 签订日期

-- comment on column v_scm_sale_contract_detail.customer_name not supported: 客户名称

-- comment on column v_scm_sale_contract_detail.material_id not supported: 物料id

-- comment on column v_scm_sale_contract_detail.price not supported: 单价

-- comment on column v_scm_sale_contract_detail.quantity not supported: 订货数量

-- comment on column v_scm_sale_contract_detail.amount not supported: 金额

-- comment on column v_scm_sale_contract_detail.material_name not supported: 物料名称

-- comment on column v_scm_sale_contract_detail.material_model not supported: 型号

-- comment on column v_scm_sale_contract_detail.material_specification not supported: 规格

-- comment on column v_scm_sale_contract_detail.material_unit not supported: 单位

