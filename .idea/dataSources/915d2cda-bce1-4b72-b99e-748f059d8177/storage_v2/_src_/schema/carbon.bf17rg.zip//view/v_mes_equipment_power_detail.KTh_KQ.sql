create definer = root@localhost view v_mes_equipment_power_detail as
select `t`.`equipment_id`        AS `equipment_id`,
       `q`.`name`                AS `equipment_name`,
       `p`.`plan_id`             AS `plan_id`,
       `p`.`bom_id`              AS `bom_id`,
       `p`.`order_id`            AS `order_id`,
       `p`.`product_date`        AS `product_date`,
       `p`.`material_id`         AS `material_id`,
       `p`.`require_quantity`    AS `require_quantity`,
       `p`.`product_quantity`    AS `product_quantity`,
       `p`.`process_id`          AS `process_id`,
       `p`.`product_line_id`     AS `product_line_id`,
       `p`.`power_consume`       AS `power_consume`,
       `p`.`process_name`        AS `process_name`,
       `p`.`total_power_consume` AS `total_power_consume`,
       `p`.`product_line_name`   AS `product_line_name`
from ((`carbon`.`mes_factory_model_detail` `t` left join `carbon`.`mes_equipment` `q`
       on ((`q`.`id` = `t`.`equipment_id`))) left join `carbon`.`v_mes_product_power_detail` `p`
      on ((`p`.`product_line_id` = `t`.`product_line_id`)));

-- comment on column v_mes_equipment_power_detail.equipment_id not supported: 设备编号

-- comment on column v_mes_equipment_power_detail.equipment_name not supported: 名称

-- comment on column v_mes_equipment_power_detail.plan_id not supported: 计划编号

-- comment on column v_mes_equipment_power_detail.bom_id not supported: BOM单编号

-- comment on column v_mes_equipment_power_detail.order_id not supported: 订单编号

-- comment on column v_mes_equipment_power_detail.product_date not supported: 生产日期

-- comment on column v_mes_equipment_power_detail.material_id not supported: 物料编号

-- comment on column v_mes_equipment_power_detail.require_quantity not supported: 待产数量

-- comment on column v_mes_equipment_power_detail.product_quantity not supported: 已产数量

-- comment on column v_mes_equipment_power_detail.process_id not supported: 工艺编号

-- comment on column v_mes_equipment_power_detail.product_line_id not supported: 生产线编号

-- comment on column v_mes_equipment_power_detail.power_consume not supported: 单位耗电量

-- comment on column v_mes_equipment_power_detail.process_name not supported: 工艺名称

-- comment on column v_mes_equipment_power_detail.product_line_name not supported: 生产线名称

