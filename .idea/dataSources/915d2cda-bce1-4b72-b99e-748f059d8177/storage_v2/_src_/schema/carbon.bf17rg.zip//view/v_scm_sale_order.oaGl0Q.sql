create definer = root@localhost view v_scm_sale_order as
select `o`.`id`                                  AS `order_id`,
       `o`.`order_no`                            AS `order_no`,
       `o`.`customer_id`                         AS `customer_id`,
       `c`.`name`                                AS `customer_name`,
       ifnull(`o`.`order_amount`, 0)             AS `order_amount`,
       date_format(`o`.`apply_time`, '%Y')       AS `order_year`,
       quarter(`o`.`apply_time`)                 AS `order_quarter`,
       month(`o`.`apply_time`)                   AS `order_month`,
       date_format(`o`.`apply_time`, '%Y-%m')    AS `order_year_month`,
       date_format(`o`.`apply_time`, '%Y-%m-%d') AS `order_date`
from (`carbon`.`scm_sale_order` `o` left join `carbon`.`scm_sale_customer` `c` on ((`o`.`customer_id` = `c`.`id`)))
where (`o`.`audit_status` = '1');

-- comment on column v_scm_sale_order.order_id not supported: 编号

-- comment on column v_scm_sale_order.order_no not supported: 订单编号

-- comment on column v_scm_sale_order.customer_id not supported: 客户id

-- comment on column v_scm_sale_order.customer_name not supported: 客户名称

