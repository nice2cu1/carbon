create definer = root@localhost view v_scm_purchase_contract as
select `pc`.`id`                                 AS `contract_id`,
       `pc`.`contract_no`                        AS `contract_no`,
       `pc`.`supplier_id`                        AS `supplier_id`,
       `pc`.`apply_id`                           AS `apply_id`,
       `pc`.`apply_no`                           AS `apply_no`,
       `s`.`name`                                AS `supplier_name`,
       ifnull(`pc`.`amount`, 0)                  AS `contract_amount`,
       date_format(`pc`.`sign_date`, '%Y')       AS `contract_year`,
       quarter(`pc`.`sign_date`)                 AS `contract_quarter`,
       month(`pc`.`sign_date`)                   AS `contract_month`,
       date_format(`pc`.`sign_date`, '%Y-%m')    AS `contract_year_month`,
       date_format(`pc`.`sign_date`, '%Y-%m-%d') AS `contract_date`
from (`carbon`.`scm_purchase_contract` `pc` left join `carbon`.`scm_purchase_supplier` `s`
      on ((`pc`.`supplier_id` = `s`.`id`)))
where (`pc`.`audit_status` = '1');

-- comment on column v_scm_purchase_contract.contract_id not supported: 编号

-- comment on column v_scm_purchase_contract.contract_no not supported: 合同编号

-- comment on column v_scm_purchase_contract.supplier_id not supported: 供应商id

-- comment on column v_scm_purchase_contract.apply_id not supported: 申请id

-- comment on column v_scm_purchase_contract.apply_no not supported: 申请编号

-- comment on column v_scm_purchase_contract.supplier_name not supported: 供应商名称

