create definer = root@localhost view v_mes_product_power_detail as
select `t`.`plan_id`                                  AS `plan_id`,
       `t`.`bom_id`                                   AS `bom_id`,
       `t`.`order_id`                                 AS `order_id`,
       `t`.`product_date`                             AS `product_date`,
       `t`.`material_id`                              AS `material_id`,
       `t`.`require_quantity`                         AS `require_quantity`,
       `t`.`product_quantity`                         AS `product_quantity`,
       `t`.`process_id`                               AS `process_id`,
       `t`.`product_line_id`                          AS `product_line_id`,
       `p`.`power_consume`                            AS `power_consume`,
       `p`.`process_name`                             AS `process_name`,
       (`t`.`product_quantity` * `p`.`power_consume`) AS `total_power_consume`,
       `f`.`product_line_name`                        AS `product_line_name`,
       `m`.`name`                                     AS `material_name`,
       `m`.`model`                                    AS `material_model`,
       `m`.`specification`                            AS `material_specification`,
       `m`.`unit`                                     AS `material_unit`
from (((`carbon`.`mes_product_schedule` `t` left join `carbon`.`mes_process_model` `p`
        on ((`p`.`id` = `t`.`process_id`))) left join `carbon`.`mes_factory_model` `f`
       on ((`f`.`id` = `t`.`product_line_id`))) left join `carbon`.`wms_material_info` `m`
      on ((`m`.`id` = `t`.`material_id`)));

-- comment on column v_mes_product_power_detail.plan_id not supported: 计划编号

-- comment on column v_mes_product_power_detail.bom_id not supported: BOM单编号

-- comment on column v_mes_product_power_detail.order_id not supported: 订单编号

-- comment on column v_mes_product_power_detail.product_date not supported: 生产日期

-- comment on column v_mes_product_power_detail.material_id not supported: 物料编号

-- comment on column v_mes_product_power_detail.require_quantity not supported: 待产数量

-- comment on column v_mes_product_power_detail.product_quantity not supported: 已产数量

-- comment on column v_mes_product_power_detail.process_id not supported: 工艺编号

-- comment on column v_mes_product_power_detail.product_line_id not supported: 生产线编号

-- comment on column v_mes_product_power_detail.power_consume not supported: 单位耗电量

-- comment on column v_mes_product_power_detail.process_name not supported: 工艺名称

-- comment on column v_mes_product_power_detail.product_line_name not supported: 生产线名称

-- comment on column v_mes_product_power_detail.material_name not supported: 物料名称

-- comment on column v_mes_product_power_detail.material_model not supported: 型号

-- comment on column v_mes_product_power_detail.material_specification not supported: 规格

-- comment on column v_mes_product_power_detail.material_unit not supported: 单位

