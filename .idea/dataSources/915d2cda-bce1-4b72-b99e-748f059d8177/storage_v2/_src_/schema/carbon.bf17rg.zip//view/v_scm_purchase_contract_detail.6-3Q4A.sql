create definer = root@localhost view v_scm_purchase_contract_detail as
select `cd`.`contract_id`  AS `contract_id`,
       `cd`.`material_id`  AS `material_id`,
       `m`.`name`          AS `material_name`,
       `m`.`code`          AS `material_code`,
       `m`.`model`         AS `material_model`,
       `m`.`specification` AS `material_specification`,
       `m`.`unit`          AS `material_unit`,
       `cd`.`price`        AS `price`,
       `cd`.`quantity`     AS `quantity`,
       `cd`.`amount`       AS `amount`,
       `c`.`supplier_id`   AS `supplier_id`,
       `s`.`name`          AS `supplier_name`,
       `c`.`contract_no`   AS `contract_no`,
       `c`.`sign_date`     AS `sign_date`
from (((`carbon`.`scm_purchase_contract_detail` `cd` left join `carbon`.`scm_purchase_contract` `c`
        on ((`c`.`id` = `cd`.`contract_id`))) left join `carbon`.`scm_purchase_supplier` `s`
       on ((`s`.`id` = `c`.`supplier_id`))) left join `carbon`.`wms_material_info` `m`
      on ((`m`.`id` = `cd`.`material_id`)));

-- comment on column v_scm_purchase_contract_detail.contract_id not supported: 合同id

-- comment on column v_scm_purchase_contract_detail.material_id not supported: 物料id

-- comment on column v_scm_purchase_contract_detail.material_name not supported: 物料名称

-- comment on column v_scm_purchase_contract_detail.material_code not supported: 物料编码

-- comment on column v_scm_purchase_contract_detail.material_model not supported: 型号

-- comment on column v_scm_purchase_contract_detail.material_specification not supported: 规格

-- comment on column v_scm_purchase_contract_detail.material_unit not supported: 单位

-- comment on column v_scm_purchase_contract_detail.price not supported: 单价

-- comment on column v_scm_purchase_contract_detail.quantity not supported: 采购数量

-- comment on column v_scm_purchase_contract_detail.amount not supported: 金额

-- comment on column v_scm_purchase_contract_detail.supplier_id not supported: 供应商id

-- comment on column v_scm_purchase_contract_detail.supplier_name not supported: 供应商名称

-- comment on column v_scm_purchase_contract_detail.contract_no not supported: 合同编号

-- comment on column v_scm_purchase_contract_detail.sign_date not supported: 签约日期

