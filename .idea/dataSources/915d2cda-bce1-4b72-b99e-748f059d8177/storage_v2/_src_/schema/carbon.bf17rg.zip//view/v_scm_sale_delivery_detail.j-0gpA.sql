create definer = root@localhost view v_scm_sale_delivery_detail as
select `sd`.`contract_no`    AS `contract_no`,
       `d`.`delivery_id`     AS `delivery_id`,
       `sd`.`customer_id`    AS `customer_id`,
       `c`.`name`            AS `customer_name`,
       `d`.`material_id`     AS `material_id`,
       `m`.`name`            AS `material_name`,
       `m`.`code`            AS `material_code`,
       `m`.`model`           AS `material_model`,
       `m`.`specification`   AS `material_specification`,
       `m`.`unit`            AS `material_unit`,
       `d`.`quantity`        AS `quantity`,
       `d`.`return_quantity` AS `return_quantity`
from (((`carbon`.`scm_sale_delivery_detail` `d` join `carbon`.`scm_sale_delivery` `sd`
        on ((`sd`.`id` = `d`.`delivery_id`))) left join `carbon`.`wms_material_info` `m`
       on ((`m`.`id` = `d`.`material_id`))) left join `carbon`.`scm_sale_customer` `c`
      on ((`c`.`id` = `sd`.`customer_id`)));

-- comment on column v_scm_sale_delivery_detail.contract_no not supported: 合同编号

-- comment on column v_scm_sale_delivery_detail.delivery_id not supported: 发货id

-- comment on column v_scm_sale_delivery_detail.customer_id not supported: 客户id

-- comment on column v_scm_sale_delivery_detail.customer_name not supported: 客户名称

-- comment on column v_scm_sale_delivery_detail.material_id not supported: 物料id

-- comment on column v_scm_sale_delivery_detail.material_name not supported: 物料名称

-- comment on column v_scm_sale_delivery_detail.material_code not supported: 物料编码

-- comment on column v_scm_sale_delivery_detail.material_model not supported: 型号

-- comment on column v_scm_sale_delivery_detail.material_specification not supported: 规格

-- comment on column v_scm_sale_delivery_detail.material_unit not supported: 单位

-- comment on column v_scm_sale_delivery_detail.quantity not supported: 发货数量

-- comment on column v_scm_sale_delivery_detail.return_quantity not supported: 退货数量

