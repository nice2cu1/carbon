create definer = root@localhost view v_wms_out_warehouse_detail as
select `t`.`material_id`    AS `material_id`,
       `t`.`batch_no`       AS `batch_no`,
       `t`.`out_quantity`   AS `out_quantity`,
       `t`.`warehouse_id`   AS `wh_id`,
       `t`.`wh_region_id`   AS `wh_region_id`,
       `t`.`wh_location_id` AS `wh_location_id`,
       `p`.`biz_type`       AS `biz_type`,
       `p`.`apply_time`     AS `in_wh_date`,
       `m`.`name`           AS `material_name`,
       `m`.`model`          AS `material_model`,
       `m`.`specification`  AS `material_specification`,
       `m`.`unit`           AS `material_unit`,
       `w`.`name`           AS `wh_name`,
       `r`.`name`           AS `wh_region_name`,
       `wl`.`name`          AS `wh_location_name`
from (((((`carbon`.`wms_out_warehouse_apply_detail` `t` left join `carbon`.`wms_out_warehouse_apply` `p`
          on ((`p`.`id` = `t`.`apply_id`))) left join `carbon`.`wms_warehouse` `w`
         on ((`w`.`id` = `t`.`warehouse_id`))) left join `carbon`.`wms_warehouse_region` `r`
        on ((`r`.`id` = `t`.`wh_region_id`))) left join `carbon`.`wms_warehouse_location` `wl`
       on ((`wl`.`id` = `t`.`wh_location_id`))) left join `carbon`.`wms_material_info` `m`
      on ((`m`.`id` = `t`.`material_id`)))
where (`p`.`bill_status` = '3');

-- comment on column v_wms_out_warehouse_detail.material_id not supported: 物料档案编号

-- comment on column v_wms_out_warehouse_detail.batch_no not supported: 生产批号

-- comment on column v_wms_out_warehouse_detail.out_quantity not supported: 发货数量

-- comment on column v_wms_out_warehouse_detail.wh_id not supported: 仓库编号

-- comment on column v_wms_out_warehouse_detail.wh_region_id not supported: 库区编号

-- comment on column v_wms_out_warehouse_detail.wh_location_id not supported: 库位编号

-- comment on column v_wms_out_warehouse_detail.biz_type not supported: 业务类型：3领料出库4发货出库

-- comment on column v_wms_out_warehouse_detail.in_wh_date not supported: 申请日期

-- comment on column v_wms_out_warehouse_detail.material_name not supported: 物料名称

-- comment on column v_wms_out_warehouse_detail.material_model not supported: 型号

-- comment on column v_wms_out_warehouse_detail.material_specification not supported: 规格

-- comment on column v_wms_out_warehouse_detail.material_unit not supported: 单位

-- comment on column v_wms_out_warehouse_detail.wh_name not supported: 仓库名

-- comment on column v_wms_out_warehouse_detail.wh_region_name not supported: 库区名称

-- comment on column v_wms_out_warehouse_detail.wh_location_name not supported: 库区名称

