create definer = root@localhost view v_scm_sale_plan_detail as
select `p`.`plan_no`     AS `plan_no`,
       `p`.`title`       AS `title`,
       `p`.`type`        AS `type`,
       `p`.`start_date`  AS `start_date`,
       `p`.`end_date`    AS `end_date`,
       `d`.`sale_amount` AS `sale_amount`,
       `d`.`material_id` AS `material_id`,
       `m`.`name`        AS `material_name`
from ((`carbon`.`scm_sale_plan_detail` `d` join `carbon`.`scm_sale_plan` `p`
       on ((`p`.`id` = `d`.`plan_id`))) left join `carbon`.`wms_material_info` `m` on ((`m`.`id` = `d`.`material_id`)));

-- comment on column v_scm_sale_plan_detail.plan_no not supported: 计划单号

-- comment on column v_scm_sale_plan_detail.title not supported: 计划标题

-- comment on column v_scm_sale_plan_detail.type not supported: 计划类型：1年度计划 2季度计划 3月计划

-- comment on column v_scm_sale_plan_detail.start_date not supported: 起始日期

-- comment on column v_scm_sale_plan_detail.end_date not supported: 结束日期

-- comment on column v_scm_sale_plan_detail.sale_amount not supported: 销售额

-- comment on column v_scm_sale_plan_detail.material_id not supported: 产品id

-- comment on column v_scm_sale_plan_detail.material_name not supported: 物料名称

